# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['inabox']
install_requires = \
['requests>=2.25,<3.0']

entry_points = \
{'console_scripts': ['inabox = inabox:main']}

setup_kwargs = {
    'name': 'inabox',
    'version': '0.5.6',
    'description': 'Knowit Automation lifecycle management',
    'long_description': None,
    'author': 'Jakob Holst',
    'author_email': 'jakob.holst@knowit.dk',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://inabox.openknowit.com',
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
